// js/addSession.js (hardened)

import { getAllSubjects, addSubject, addSession } from './db.js';
import { uuid, today, getCurrentTime, calcDurationMins, minsToHHMM, showToast, esc } from './utils.js';

// Module-level state — reset on every render call
let _subjects       = [];
let _selectedActivity = 'study';
// Track the document-level click listener so we can remove it before re-adding
let _docClickHandler = null;

export async function renderAddSession() {
  // Reset module state cleanly each time this tab is rendered
  _subjects        = await getAllSubjects();
  _selectedActivity = 'study';

  // Remove previous document-level listener to prevent accumulation
  if (_docClickHandler) {
    document.removeEventListener('click', _docClickHandler);
    _docClickHandler = null;
  }

  const panel     = document.getElementById('tab-add');
  const todayStr  = today();

  panel.innerHTML = `
    <div class="add-session-wrap">
      <div class="add-session-header">
        <div class="add-session-title">Log Session</div>
        <div class="add-session-sub">Record what you studied</div>
      </div>

      <div class="form-group">
        <label class="form-label">Date</label>
        <input type="date" class="form-input" id="sess-date"
               value="${todayStr}" max="${todayStr}">
      </div>

      <div class="form-group">
        <label class="form-label">Subject</label>
        <div class="subject-input-wrap" id="sess-subject-wrap">
          <input type="text" class="form-input" id="sess-subject"
                 placeholder="Type or select subject…" autocomplete="off" spellcheck="false">
          <div class="subject-dropdown hidden" id="subject-dropdown"></div>
        </div>
      </div>

      <div class="form-group">
        <label class="form-label">Topic</label>
        <input type="text" class="form-input" id="sess-topic"
               placeholder="What did you study?">
      </div>

      <div class="form-group">
        <label class="form-label">Activity Type</label>
        <div class="activity-grid" id="activity-grid">
          <button class="activity-btn selected"       data-type="study">  <span class="activity-icon">📖</span>Study</button>
          <button class="activity-btn review"         data-type="review"> <span class="activity-icon">🔄</span>Review</button>
          <button class="activity-btn test"           data-type="test">   <span class="activity-icon">📝</span>Test</button>
          <button class="activity-btn exam"           data-type="exam">   <span class="activity-icon">🎯</span>Exam</button>
        </div>
      </div>

      <!-- Only shown for test / exam -->
      <div class="form-group" id="qcount-group" style="display:none">
        <label class="form-label">Question Count</label>
        <input type="number" class="form-input" id="sess-qcount"
               placeholder="0" min="0" inputmode="numeric">
      </div>

      <div class="form-row" style="margin-bottom:14px">
        <div class="form-group" style="margin-bottom:0">
          <label class="form-label">Start Time</label>
          <input type="time" class="form-input" id="sess-start">
        </div>
        <div class="form-group" style="margin-bottom:0">
          <label class="form-label">End Time</label>
          <input type="time" class="form-input" id="sess-end">
        </div>
      </div>

      <div style="margin-bottom:14px;display:flex;align-items:center;gap:8px">
        <span style="font-size:0.72rem;color:var(--text-muted)">Duration:</span>
        <div class="duration-pill" id="duration-display">— not set —</div>
      </div>

      <div class="form-group">
        <label class="form-label">
          Notes
          <span style="color:var(--text-muted);font-weight:400;font-size:0.68rem;text-transform:none;letter-spacing:0">(optional)</span>
        </label>
        <textarea class="form-textarea" id="sess-notes"
                  placeholder="Key learnings, difficulties…"></textarea>
      </div>

      <button class="btn btn-primary btn-full" id="save-session-btn">
        Save Session
      </button>
      <div style="height:16px"></div>
    </div>
  `;

  initSubjectInput();
  initActivityBtns();
  initTimePicker();
  initSave();
}

// ── Subject autocomplete ──────────────────────────────────────────────────────
function initSubjectInput() {
  const input    = document.getElementById('sess-subject');
  const dropdown = document.getElementById('subject-dropdown');
  const wrap     = document.getElementById('sess-subject-wrap');

  function renderDropdown(filter) {
    const q        = (filter || '').toLowerCase().trim();
    const filtered = _subjects.filter(s => s.name.toLowerCase().includes(q));
    const hasExact = _subjects.some(s => s.name.toLowerCase() === q);

    let html = filtered
      .map(s => `<div class="subject-option" data-name="${esc(s.name)}">${esc(s.name)}</div>`)
      .join('');

    if (q && !hasExact) {
      html += `<div class="subject-option subject-option-add" data-add="${esc(filter)}">
                 + Add &quot;${esc(filter)}&quot;
               </div>`;
    }

    if (!html) {
      html = `<div class="subject-option" style="color:var(--text-muted)">No subjects yet — type to add</div>`;
    }

    dropdown.innerHTML = html;

    // Delegate option clicks — re-bind each render
    dropdown.querySelectorAll('.subject-option').forEach(opt => {
      opt.addEventListener('mousedown', async (e) => {
        // Use mousedown so it fires before the input blur that would hide dropdown
        e.preventDefault();
        if (opt.dataset.add) {
          const name     = opt.dataset.add.trim();
          const newSubj  = { id: uuid(), name, createdAt: Date.now() };
          await addSubject(newSubj);
          _subjects.push(newSubj);
          input.value = name;
        } else {
          input.value = opt.dataset.name;
        }
        dropdown.classList.add('hidden');
      });
    });
  }

  function openDropdown() {
    renderDropdown(input.value);
    dropdown.classList.remove('hidden');
  }

  function closeDropdown() {
    dropdown.classList.add('hidden');
  }

  input.addEventListener('focus', openDropdown);
  input.addEventListener('input', openDropdown);

  // Document-level handler — stored so we can remove it on next render
  _docClickHandler = (e) => {
    if (!wrap.contains(e.target)) closeDropdown();
  };
  document.addEventListener('click', _docClickHandler);
}

// ── Activity type buttons ─────────────────────────────────────────────────────
function initActivityBtns() {
  const grid = document.getElementById('activity-grid');
  if (!grid) return;

  grid.addEventListener('click', (e) => {
    const btn = e.target.closest('.activity-btn');
    if (!btn) return;

    grid.querySelectorAll('.activity-btn').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
    _selectedActivity = btn.dataset.type;

    const qgroup = document.getElementById('qcount-group');
    if (qgroup) {
      qgroup.style.display =
        (_selectedActivity === 'test' || _selectedActivity === 'exam') ? 'block' : 'none';
    }
  });
}

// ── Time picker / duration ────────────────────────────────────────────────────
function initTimePicker() {
  const startEl = document.getElementById('sess-start');
  const endEl   = document.getElementById('sess-end');
  const durEl   = document.getElementById('duration-display');

  // Default start = now, leave end blank
  startEl.value = getCurrentTime();

  function update() {
    const mins = calcDurationMins(startEl.value, endEl.value);
    durEl.textContent = mins > 0 ? minsToHHMM(mins) : '— not set —';
  }

  startEl.addEventListener('change', update);
  endEl.addEventListener('change', update);
  // Also fire on input for mobile pickers that don't fire change until blur
  startEl.addEventListener('input', update);
  endEl.addEventListener('input', update);
}

// ── Save ─────────────────────────────────────────────────────────────────────
function initSave() {
  const saveBtn = document.getElementById('save-session-btn');
  if (!saveBtn) return;

  saveBtn.addEventListener('click', async () => {
    const date      = (document.getElementById('sess-date').value || '').trim();
    const subject   = (document.getElementById('sess-subject').value || '').trim();
    const topic     = (document.getElementById('sess-topic').value || '').trim();
    const startTime = (document.getElementById('sess-start').value || '').trim();
    const endTime   = (document.getElementById('sess-end').value || '').trim();
    const notes     = (document.getElementById('sess-notes').value || '').trim();
    const qcountRaw = (document.getElementById('sess-qcount').value || '').trim();

    // Validation
    if (!date)      { showToast('Date is required', 'error'); return; }
    if (!subject)   { showToast('Subject is required', 'error'); return; }
    if (!topic)     { showToast('Topic is required', 'error'); return; }
    if (!startTime) { showToast('Start time is required', 'error'); return; }
    if (!endTime)   { showToast('End time is required', 'error'); return; }

    const dur = calcDurationMins(startTime, endTime);
    if (dur <= 0) {
      showToast('End time must be after start time', 'error');
      return;
    }

    // Auto-add subject if not in list
    const exists = _subjects.find(s => s.name.toLowerCase() === subject.toLowerCase());
    if (!exists) {
      const newSubj = { id: uuid(), name: subject, createdAt: Date.now() };
      await addSubject(newSubj);
      _subjects.push(newSubj);
    }

    const needsQ       = _selectedActivity === 'test' || _selectedActivity === 'exam';
    const questionCount = needsQ ? (parseInt(qcountRaw, 10) || 0) : 0;

    const session = {
      id           : uuid(),
      date,
      subject,
      topic,
      activityType : _selectedActivity,
      questionCount,
      startTime,
      endTime,
      notes,
      createdAt    : Date.now(),
    };

    // Disable button during save to prevent double-submit
    saveBtn.disabled    = true;
    saveBtn.textContent = 'Saving…';
    try {
      await addSession(session);
      showToast('Session saved! 🎉', 'success');
      await renderAddSession(); // reset the form
    } catch (err) {
      console.error('Save session error:', err);
      showToast('Failed to save session', 'error');
      saveBtn.disabled    = false;
      saveBtn.textContent = 'Save Session';
    }
  });
}
