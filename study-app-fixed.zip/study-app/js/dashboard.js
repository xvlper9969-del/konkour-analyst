// js/dashboard.js (hardened)

import { getSessionsByDate, getPlannerByDate } from './db.js';
import { today, minsToHHMM, calcDurationMins, formatDate, esc } from './utils.js';

export async function renderDashboard() {
  const panel = document.getElementById('tab-dashboard');
  panel.innerHTML = `<div class="loading-spinner"><div class="spinner"></div></div>`;

  const todayStr = today();
  const [sessions, tasks] = await Promise.all([
    getSessionsByDate(todayStr),
    getPlannerByDate(todayStr),
  ]);

  // Guard: ensure arrays even if DB returns unexpected values
  const safeSessions = Array.isArray(sessions) ? sessions : [];
  const safeTasks    = Array.isArray(tasks)    ? tasks    : [];

  const totalMins = safeSessions.reduce((acc, s) => acc + calcDurationMins(s.startTime, s.endTime), 0);
  const totalQ    = safeSessions.reduce((acc, s) => acc + (Number(s.questionCount) || 0), 0);
  const completed = safeTasks.filter(t => t.completed).length;
  const remaining = safeTasks.length - completed;
  const pct       = safeTasks.length > 0 ? Math.round((completed / safeTasks.length) * 100) : 0;

  const hour     = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

  panel.innerHTML = `
    <div class="dash-greeting">
      <div class="dash-greeting-text">${greeting} 👋</div>
      <div class="dash-greeting-sub">${formatDate(todayStr)}</div>
    </div>

    <div class="dash-progress-card">
      <div class="dash-progress-header">
        <span class="dash-progress-title">Daily Progress</span>
        <span class="dash-progress-pct">${pct}%</span>
      </div>
      <div class="progress-bar-wrap">
        <div class="progress-bar-fill" style="width:${pct}%"></div>
      </div>
      <div style="display:flex;gap:16px;margin-top:12px;">
        <span style="font-size:0.72rem;color:var(--text-muted)">
          ${completed} of ${safeTasks.length} tasks done
        </span>
        <span style="font-size:0.72rem;color:var(--text-muted)">
          ${safeSessions.length} session${safeSessions.length !== 1 ? 's' : ''} logged
        </span>
      </div>
    </div>

    <div class="dash-stats-grid">
      <div class="dash-stat-card time">
        <div class="dash-stat-icon">⏱</div>
        <div class="dash-stat-val time">${minsToHHMM(totalMins)}</div>
        <div class="dash-stat-name">Study Time</div>
      </div>
      <div class="dash-stat-card questions">
        <div class="dash-stat-icon">📝</div>
        <div class="dash-stat-val questions">${totalQ}</div>
        <div class="dash-stat-name">Questions</div>
      </div>
      <div class="dash-stat-card done">
        <div class="dash-stat-icon">✅</div>
        <div class="dash-stat-val done">${completed}</div>
        <div class="dash-stat-name">Tasks Done</div>
      </div>
      <div class="dash-stat-card remaining">
        <div class="dash-stat-icon">⏳</div>
        <div class="dash-stat-val remaining">${remaining}</div>
        <div class="dash-stat-name">Remaining</div>
      </div>
    </div>

    <div class="section-block">
      <div class="section-header">
        <div class="section-label">Today's Sessions</div>
      </div>
      ${renderSessionsList(safeSessions)}
    </div>
  `;
}

function renderSessionsList(sessions) {
  if (sessions.length === 0) {
    return `<div class="empty-state">
      <div class="empty-state-icon">📚</div>
      <div class="empty-state-text">No sessions logged today.<br>Tap <b>+ Session</b> to start tracking.</div>
    </div>`;
  }
  const sorted = [...sessions].sort((a, b) => (a.startTime || '').localeCompare(b.startTime || ''));
  return sorted.map(s => {
    const dur = calcDurationMins(s.startTime, s.endTime);
    return `<div class="session-item">
      <div class="session-item-dot ${esc(s.activityType)}"></div>
      <div class="session-item-info">
        <div class="session-item-subject">${esc(s.subject)}</div>
        <div class="session-item-meta">${esc(s.topic)}${s.questionCount ? ` · ${Number(s.questionCount)}Q` : ''}</div>
      </div>
      <div class="session-item-time">
        ${esc(s.startTime)}–${esc(s.endTime)}<br>
        <span style="color:var(--accent)">${minsToHHMM(dur)}</span>
      </div>
    </div>`;
  }).join('');
}
